<?php
die();
// Na! I am a dot net file
?>