jQuery(document).ready(function(){
	request_users_cul();

	// event for user role selectbox
	jQuery('.filterBy select').on('change', function(){
		jQuery('body').find('#current-page').val('1');
		request_users_cul();
	});
	
	// pagination links event
	jQuery('.pagination-links').on('click', 'a.active', function(event){
		clickd_lnk = this;
		if( jQuery(clickd_lnk).hasClass('first-page') ) jQuery('body').find('#current-page').val('1');
		else if( jQuery(clickd_lnk).hasClass('previous-page') ) jQuery('body').find('#current-page').val( parseInt(jQuery('body').find('#current-page').val()) - 1);
		else if( jQuery(clickd_lnk).hasClass('next-page') ) jQuery('body').find('#current-page').val( parseInt(jQuery('body').find('#current-page').val()) + 1);
		else if( jQuery(clickd_lnk).hasClass('last-page') ) jQuery('body').find('#current-page').val( jQuery('body').find('.total-pages:first').text() );
		request_users_cul();
		event.preventDefault();
	});

	// sorting links event
	jQuery('.wp-list-table thead').on('click', 'th.sortable, th.sorted', function(event){
		clickd_srt = this;
		jQuery('body').find('#current-page').val('1');
		if( jQuery(clickd_srt).hasClass('desc') ){
			jQuery('body').find('#order').val('desc');
			jQuery(clickd_srt).addClass('asc');
			jQuery(clickd_srt).removeClass('desc');
		}
		else if( jQuery(clickd_srt).hasClass('asc') ){
			jQuery('body').find('#order').val('asc');
			jQuery(clickd_srt).addClass('desc');
			jQuery(clickd_srt).removeClass('asc');

		}
		jQuery('body').find('#orderby').val( jQuery(clickd_srt).attr('id') );
		request_users_cul();
		event.preventDefault();
	});
});

// function for requesting the response of user list
function request_users_cul(){
    jQuery('.wp-list-table tbody .loader-img').show();
    jQuery('.wp-list-table tbody tr:not(.loader-img)').remove();
	
	jQuery.post(
	    ajaxurl, 
	    {
	    	// values to be used in user_query
	        'action'	: 'render_cul',
	        'role'		: jQuery('.filterBy select').find("option:selected").attr('value'),
	        'page'		: jQuery('body').find('#current-page').val(),
	        'order'		: jQuery('body').find('#order').val(),
	        'orderby'	: jQuery('body').find('#orderby').val(),
	    }, 
	    function(response) {
	    	// splitting the response to get table data and other parameter values
	        table = response.split('<br>----tabl!!jsn!seperator---<br>')[0];
	        valsJsn = response.split('<br>----tabl!!jsn!seperator---<br>')[1];
	        vals = JSON.parse(valsJsn);

	        // using table data
	        jQuery('.wp-list-table tbody').append(table);

	        // using parameter values
	        jQuery('.tablenav-pages .displaying-num').text( vals['total_users'] + ' users');
	        jQuery('body').find('.total-pages').text( Math.ceil( parseFloat(vals['total_users']) / parseFloat(vals['number'])) );
	        jQuery('body').find('.current-page').text(jQuery('body').find('#current-page').val());

	        // disable navigation links as per the current page and total pages
	        if(jQuery('body').find('#current-page').val() == '1'){
	        	jQuery('.pagination-links .first-page').removeClass('active').addClass('inactive');
	        	jQuery('.pagination-links .previous-page').removeClass('active').addClass('inactive');
	        }
	        else{
	        	jQuery('.pagination-links .first-page').removeClass('inactive').addClass('active');
	        	jQuery('.pagination-links .previous-page').removeClass('inactive').addClass('active');
	        }
	        if(jQuery('body').find('#current-page').val() == jQuery('body').find('.total-pages:first').text()){
	        	jQuery('.pagination-links .next-page').removeClass('active').addClass('inactive');
	        	jQuery('.pagination-links .last-page').removeClass('active').addClass('inactive');
	        }
	        else{
	        	jQuery('.pagination-links .next-page').removeClass('inactive').addClass('active');
	        	jQuery('.pagination-links .last-page').removeClass('inactive').addClass('active');
	        }

	        jQuery('.wp-list-table tbody .loader-img').hide();
	    }
	);
}