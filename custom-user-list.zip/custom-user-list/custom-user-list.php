<?php
/*
Plugin Name: Custom User List
Description: Showing custom user list with role filtration
Author: Baljinder Singh
Author URI: http://wptxs.us/
Version: 1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die('Direct access is not allowed');
}

//Define constant
define( 'CUL_SLUG', 'custom-user-list');
define( 'CUL_PLUGIN_FILE', __FILE__ );
define( 'CUL_PLUGIN_DIR', __DIR__ );
define( 'CUL_PLUGIN_URL', plugin_dir_url(__FILE__) );

/* Enqueue scripts and styles */
add_action('admin_enqueue_scripts', function($hook){
    if( $hook == 'toplevel_page_custom-user-list'){
        wp_enqueue_script(CUL_SLUG.'-min-js', CUL_PLUGIN_URL.'assets/js/custom-user-list.min.js', array('jquery'));
        wp_enqueue_style(CUL_SLUG.'-min-style', CUL_PLUGIN_URL.'assets/css/custom-user-list.min.css');
    }
});

/* Creating admin menu */
add_action('admin_menu', function(){
    add_menu_page(__( 'Custom User List', CUL_SLUG ),__( 'Custom User List', CUL_SLUG ), 'manage_options', CUL_SLUG, 'cul_user_table_function_v2', 'dashicons-admin-users', 15);
});

// render default html wrapper of page
function cul_user_table_function_v2(){
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Custom User List</h1>
        <hr class="wp-header-end">
        <h2 class="screen-reader-text">Custom User List Filteration</h2>
        <div class="filterBy">
            Filter by User Roles: 
            <select>
                <option value="">All</option>
                <?php
                foreach (get_editable_roles() as $role_name => $role_info) echo '<option value="' . $role_name . '">' . $role_info['name'] . '</option>';
                ?>
            </select>
        </div>
        <div class="tablenav top">
            <h2 class="screen-reader-text">Users list navigation</h2>
            <div class="tablenav-pages">
                <span class="displaying-num"></span>
                <span class="pagination-links">
                    <a class="first-page inactive" href="#">
                        <span class="screen-reader-text">Next page</span>
                        <span aria-hidden="true">«</span>
                    </a>
                    <a class="previous-page inactive" href="#">
                        <span class="screen-reader-text">Last page</span>
                        <span aria-hidden="true">‹</span>
                    </a>
                    <span class="paging-input">
                        <label for="current-page-selector" class="screen-reader-text">Current Page</label>
                        <span class="tablenav-paging-text">
                            <span class="current-page"></span> 
                            of 
                            <span class="total-pages"></span>
                        </span>
                    </span>
                    <a class="next-page inactive" href="#">
                        <span class="screen-reader-text">Next page</span>
                        <span aria-hidden="true">›</span>
                    </a>
                    <a class="last-page inactive" href="#">
                        <span class="screen-reader-text">Last page</span>
                        <span aria-hidden="true">»</span>
                    </a>
                </span>
            </div>
            <br class="clear">
        </div>
        <h2 class="screen-reader-text">Users list</h2>
        <table class="wp-list-table widefat fixed striped users">
            <thead>
                <tr>
                    <th scope="col" id="user_login" class="manage-column column-username column-primary sortable desc">
                        <a href="#">
                            <span>Username</span>
                            <span class="sorting-indicator"></span>
                        </a>
                    </th>
                    <th scope="col" id="display_name" class="manage-column column-name sortable desc">
                        <a href="#">
                            <span>Name</span>
                            <span class="sorting-indicator"></span>
                        </a>
                    </th>
                    <th scope="col" id="email" class="manage-column column-email">
                        <span>Email</span>
                    </th>
                    <th scope="col" id="email" class="manage-column column-role">
                        <span>Role</span>
                    </th>
                    <th scope="col" id="email" class="manage-column column-id">
                        <span>ID</span>
                    </th>
                </tr>
            </thead>

            <tbody id="the-list" data-wp-lists="list:user"> 
                <tr class="loader-img">
                    <td  colspan="5">
                        <img src="<?=CUL_PLUGIN_URL;?>assets/images/ajax-loader.gif">
                    </td>
                </tr>
            </tbody>

            <tfoot>
                <tr>
                    <th scope="col" id="username" class="manage-column column-username column-primary">
                        <span>Username</span>
                    </th>
                    <th scope="col" id="name" class="manage-column column-name">
                        <span>Name</span>
                    </th>
                    <th scope="col" id="email" class="manage-column column-email">
                        <span>Email</span>
                    </th>
                    <th scope="col" id="role" class="manage-column column-role">
                        <span>Role</span>
                    </th>
                    <th scope="col" id="id" class="manage-column column-id">
                        <span>ID</span>
                    </th>
                </tr>
            </tfoot>
        </table>
        <input type="hidden" id="order" autocomplete="off"><input type="hidden" id="orderby" autocomplete="off"><input type="hidden" id="current-page" value="1" autocomplete="off">
        <div class="tablenav top">
            <h2 class="screen-reader-text">Users list navigation</h2>
            <div class="tablenav-pages">
                <span class="displaying-num"></span>
                <span class="pagination-links">
                    <a class="first-page inactive" href="#">
                        <span class="screen-reader-text">Next page</span>
                        <span aria-hidden="true">«</span>
                    </a>
                    <a class="previous-page inactive" href="#">
                        <span class="screen-reader-text">Last page</span>
                        <span aria-hidden="true">‹</span>
                    </a>
                    <span class="paging-input">
                        <label for="current-page-selector" class="screen-reader-text">Current Page</label>
                        <span class="tablenav-paging-text">
                            <span class="current-page"></span> 
                            of 
                            <span class="total-pages"></span>
                        </span>
                    </span>
                    <a class="next-page inactive" href="#">
                        <span class="screen-reader-text">Next page</span>
                        <span aria-hidden="true">›</span>
                    </a>
                    <a class="last-page inactive" href="#">
                        <span class="screen-reader-text">Last page</span>
                        <span aria-hidden="true">»</span>
                    </a>
                </span>
            </div>
            <br class="clear">
        </div>
    </div>
    <?php
}

// ajax endpoint response for users with filteration
add_action( 'wp_ajax_render_cul', function(){
    // WP_User_Query arguments
    $args = array(
        'number'         => '10', //count of users in one page
        'count_total'    => true,
    );

    // define conditional arguements
    if( isset($_REQUEST['role']) && $_REQUEST['role'] != '' ) $args['role'] = $_REQUEST['role'];
    if( isset($_REQUEST['page']) && intval( $_REQUEST['page'] ) > 0 ) $args['offset'] = ( $args['number'] * $_REQUEST['page'] ) - $args['number'];
    if( isset($_REQUEST['order']) && isset($_REQUEST['orderby']) && $_REQUEST['orderby'] != '' && $_REQUEST['order'] != '' ){
        $args['order'] = $_REQUEST['order'];
        $args['orderby'] = $_REQUEST['orderby'];
    }

    // The User Query
    $user_query = new WP_User_Query( $args );

    // get total users count and add in args to be used in response
    $args['total_users'] = $user_query->get_total();

    // The User Loop
    if ( ! empty( $user_query->results ) ) {
        foreach ( $user_query->results as $user ) {
            ?>
            <tr>
                <td class="username column-username has-row-actions column-primary" data-colname="Username">
                    <strong><a href="<?=get_edit_user_link( $user->ID );?>"><?=$user->user_login;?></a></strong>
                    <button type="button" class="toggle-row"><span class="screen-reader-text">Show more details</span></button>
                </td>
                <td class="name column-name" data-colname="Name"><?=$user->data->display_name;?></td>
                <td class="email column-email" data-colname="Email"><a href="mailto:<?=$user->data->user_email;?>"><?=$user->data->user_email;?></a>
                </td>
                <td class="role column-role" data-colname="Role"><?=implode(', ', $user->roles);?></td>
                <td class="ridwpaid column-id" data-colname="ID"><?=$user->ID;?></td>
            </tr>
            <?php
        }
    } else {
        ?>
        <tr class="no_usrs">
            <td colspan="5">
                Sorry! No users found matching the criteria.
            </td>
        </tr>
        <?php
    }

    // append json response for some important parameters
    echo "<br>----tabl!!jsn!seperator---<br>"; //adding unique seperator for separating table and json
    echo json_encode( $args );

    die();
} );